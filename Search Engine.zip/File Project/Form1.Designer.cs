﻿namespace File_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.EditCat = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.button4 = new System.Windows.Forms.Button();
            this.side = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.ca = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.kw = new System.Windows.Forms.Button();
            this.rep = new System.Windows.Forms.Button();
            this.fn = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.arrow2 = new System.Windows.Forms.PictureBox();
            this.arrow1 = new System.Windows.Forms.PictureBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.notifications = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.editt = new System.Windows.Forms.Panel();
            this.highlight = new System.Windows.Forms.Panel();
            this.search1 = new System.Windows.Forms.Panel();
            this.Cate = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel9 = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.invaled = new System.Windows.Forms.Label();
            this.invalr = new System.Windows.Forms.Label();
            this.invalf = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.invalkey = new System.Windows.Forms.Label();
            this.invalcat = new System.Windows.Forms.Label();
            this.keyword = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.Cat = new System.Windows.Forms.Label();
            this.replace1 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.New = new System.Windows.Forms.RichTextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.old = new System.Windows.Forms.RichTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.keey = new System.Windows.Forms.Label();
            this.replace = new System.Windows.Forms.Panel();
            this.button12 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.nw = new System.Windows.Forms.TextBox();
            this.od = new System.Windows.Forms.TextBox();
            this.searchkeyword = new System.Windows.Forms.Panel();
            this.searchfile = new System.Windows.Forms.Panel();
            this.searchCat = new System.Windows.Forms.Panel();
            this.searchfcat = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.searchC = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label = new System.Windows.Forms.Label();
            this.searchF = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.searchK = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.richTextBox10 = new System.Windows.Forms.RichTextBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label34 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.arrow4 = new System.Windows.Forms.PictureBox();
            this.arrow3 = new System.Windows.Forms.PictureBox();
            this.filname = new System.Windows.Forms.Button();
            this.categ = new System.Windows.Forms.Button();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.side.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow1)).BeginInit();
            this.panel5.SuspendLayout();
            this.editt.SuspendLayout();
            this.highlight.SuspendLayout();
            this.search1.SuspendLayout();
            this.Cate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.replace1.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.replace.SuspendLayout();
            this.searchkeyword.SuspendLayout();
            this.searchfile.SuspendLayout();
            this.searchCat.SuspendLayout();
            this.searchfcat.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.panel17.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.EditCat);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.side);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(195, 717);
            this.panel1.TabIndex = 0;
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(11, 278);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(181, 56);
            this.button5.TabIndex = 8;
            this.button5.Text = "Highlight";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // EditCat
            // 
            this.EditCat.FlatAppearance.BorderSize = 0;
            this.EditCat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EditCat.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditCat.ForeColor = System.Drawing.Color.White;
            this.EditCat.Image = ((System.Drawing.Image)(resources.GetObject("EditCat.Image")));
            this.EditCat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.EditCat.Location = new System.Drawing.Point(11, 217);
            this.EditCat.Name = "EditCat";
            this.EditCat.Size = new System.Drawing.Size(181, 56);
            this.EditCat.TabIndex = 7;
            this.EditCat.Text = "Edit";
            this.EditCat.UseVisualStyleBackColor = true;
            this.EditCat.Click += new System.EventHandler(this.EditCat_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(-3, -21);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(195, 117);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(11, 160);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(181, 56);
            this.button4.TabIndex = 4;
            this.button4.Text = "Search";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // side
            // 
            this.side.BackColor = System.Drawing.Color.Red;
            this.side.Controls.Add(this.panel3);
            this.side.Location = new System.Drawing.Point(0, 102);
            this.side.Name = "side";
            this.side.Size = new System.Drawing.Size(10, 56);
            this.side.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Crimson;
            this.panel3.Location = new System.Drawing.Point(0, 57);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(12, 51);
            this.panel3.TabIndex = 3;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // button1
            // 
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(11, 102);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 56);
            this.button1.TabIndex = 2;
            this.button1.Text = "Home";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ca
            // 
            this.ca.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ca.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ca.ForeColor = System.Drawing.Color.Black;
            this.ca.Location = new System.Drawing.Point(941, 676);
            this.ca.Name = "ca";
            this.ca.Size = new System.Drawing.Size(80, 26);
            this.ca.TabIndex = 3;
            this.ca.Text = "Category";
            this.ca.UseVisualStyleBackColor = true;
            this.ca.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(195, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(896, 12);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel2_Paint);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Red;
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Location = new System.Drawing.Point(292, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(135, 142);
            this.panel4.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(21, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Files Search";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(18, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 105);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button3
            // 
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(1052, 18);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(24, 25);
            this.button3.TabIndex = 4;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button6
            // 
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(1050, 628);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(33, 32);
            this.button6.TabIndex = 5;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(1046, 673);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(42, 33);
            this.button7.TabIndex = 6;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(1050, 583);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(29, 32);
            this.button8.TabIndex = 7;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(583, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(299, 44);
            this.label2.TabIndex = 8;
            this.label2.Text = "Scorpions Team";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(603, 62);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(52, 64);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(745, 62);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(52, 64);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(675, 62);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(52, 64);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(812, 62);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(52, 64);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 12;
            this.pictureBox5.TabStop = false;
            // 
            // kw
            // 
            this.kw.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.kw.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kw.ForeColor = System.Drawing.Color.Black;
            this.kw.Location = new System.Drawing.Point(839, 676);
            this.kw.Name = "kw";
            this.kw.Size = new System.Drawing.Size(80, 26);
            this.kw.TabIndex = 14;
            this.kw.Text = "KeyWord";
            this.kw.UseVisualStyleBackColor = true;
            this.kw.Click += new System.EventHandler(this.kw_Click);
            // 
            // rep
            // 
            this.rep.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rep.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rep.ForeColor = System.Drawing.Color.Black;
            this.rep.Location = new System.Drawing.Point(633, 679);
            this.rep.Name = "rep";
            this.rep.Size = new System.Drawing.Size(80, 26);
            this.rep.TabIndex = 20;
            this.rep.Text = "Report";
            this.rep.UseVisualStyleBackColor = true;
            this.rep.Click += new System.EventHandler(this.rep_Click);
            // 
            // fn
            // 
            this.fn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fn.ForeColor = System.Drawing.Color.Black;
            this.fn.Location = new System.Drawing.Point(734, 678);
            this.fn.Name = "fn";
            this.fn.Size = new System.Drawing.Size(80, 26);
            this.fn.TabIndex = 19;
            this.fn.Text = "FileName";
            this.fn.UseVisualStyleBackColor = true;
            this.fn.Click += new System.EventHandler(this.fn_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // arrow2
            // 
            this.arrow2.BackColor = System.Drawing.Color.Transparent;
            this.arrow2.Image = ((System.Drawing.Image)(resources.GetObject("arrow2.Image")));
            this.arrow2.Location = new System.Drawing.Point(1011, 626);
            this.arrow2.Name = "arrow2";
            this.arrow2.Size = new System.Drawing.Size(36, 45);
            this.arrow2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow2.TabIndex = 21;
            this.arrow2.TabStop = false;
            // 
            // arrow1
            // 
            this.arrow1.BackColor = System.Drawing.Color.Transparent;
            this.arrow1.Image = ((System.Drawing.Image)(resources.GetObject("arrow1.Image")));
            this.arrow1.Location = new System.Drawing.Point(982, 598);
            this.arrow1.Name = "arrow1";
            this.arrow1.Size = new System.Drawing.Size(40, 35);
            this.arrow1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow1.TabIndex = 22;
            this.arrow1.TabStop = false;
            // 
            // timer2
            // 
            this.timer2.Interval = 300;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // notifications
            // 
            this.notifications.AutoSize = true;
            this.notifications.BackColor = System.Drawing.Color.Transparent;
            this.notifications.ForeColor = System.Drawing.Color.Red;
            this.notifications.Location = new System.Drawing.Point(1046, 573);
            this.notifications.Name = "notifications";
            this.notifications.Size = new System.Drawing.Size(0, 13);
            this.notifications.TabIndex = 23;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.editt);
            this.panel5.Location = new System.Drawing.Point(201, 144);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(835, 516);
            this.panel5.TabIndex = 24;
            // 
            // editt
            // 
            this.editt.Controls.Add(this.highlight);
            this.editt.Controls.Add(this.textBox14);
            this.editt.Controls.Add(this.label35);
            this.editt.Controls.Add(this.panel7);
            this.editt.Controls.Add(this.panel6);
            this.editt.Controls.Add(this.button13);
            this.editt.Controls.Add(this.button10);
            this.editt.Controls.Add(this.panel8);
            this.editt.Controls.Add(this.textBox5);
            this.editt.Controls.Add(this.label20);
            this.editt.Controls.Add(this.label19);
            this.editt.Controls.Add(this.label18);
            this.editt.Controls.Add(this.pictureBox9);
            this.editt.Location = new System.Drawing.Point(13, 8);
            this.editt.Name = "editt";
            this.editt.Size = new System.Drawing.Size(811, 494);
            this.editt.TabIndex = 24;
            // 
            // highlight
            // 
            this.highlight.Controls.Add(this.search1);
            this.highlight.Controls.Add(this.textBox13);
            this.highlight.Controls.Add(this.label33);
            this.highlight.Controls.Add(this.button9);
            this.highlight.Controls.Add(this.textBox12);
            this.highlight.Controls.Add(this.label32);
            this.highlight.Controls.Add(this.pictureBox11);
            this.highlight.Controls.Add(this.label34);
            this.highlight.Controls.Add(this.panel17);
            this.highlight.Location = new System.Drawing.Point(0, 0);
            this.highlight.Name = "highlight";
            this.highlight.Size = new System.Drawing.Size(811, 504);
            this.highlight.TabIndex = 24;
            // 
            // search1
            // 
            this.search1.Controls.Add(this.Cate);
            this.search1.Controls.Add(this.searchkeyword);
            this.search1.Controls.Add(this.pictureBox10);
            this.search1.Location = new System.Drawing.Point(0, 0);
            this.search1.Name = "search1";
            this.search1.Size = new System.Drawing.Size(811, 504);
            this.search1.TabIndex = 2;
            // 
            // Cate
            // 
            this.Cate.Controls.Add(this.splitContainer1);
            this.Cate.Location = new System.Drawing.Point(0, 0);
            this.Cate.Name = "Cate";
            this.Cate.Size = new System.Drawing.Size(811, 490);
            this.Cate.TabIndex = 22;
            this.Cate.Paint += new System.Windows.Forms.PaintEventHandler(this.Cate_Paint);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(3, 7);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel9);
            this.splitContainer1.Panel1.Controls.Add(this.invaled);
            this.splitContainer1.Panel1.Controls.Add(this.invalr);
            this.splitContainer1.Panel1.Controls.Add(this.invalf);
            this.splitContainer1.Panel1.Controls.Add(this.button11);
            this.splitContainer1.Panel1.Controls.Add(this.label9);
            this.splitContainer1.Panel1.Controls.Add(this.label10);
            this.splitContainer1.Panel1.Controls.Add(this.label8);
            this.splitContainer1.Panel1.Controls.Add(this.textBox3);
            this.splitContainer1.Panel1.Controls.Add(this.label7);
            this.splitContainer1.Panel1.Controls.Add(this.invalkey);
            this.splitContainer1.Panel1.Controls.Add(this.invalcat);
            this.splitContainer1.Panel1.Controls.Add(this.keyword);
            this.splitContainer1.Panel1.Controls.Add(this.label4);
            this.splitContainer1.Panel1.Controls.Add(this.textBox2);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.label5);
            this.splitContainer1.Panel1.Controls.Add(this.textBox1);
            this.splitContainer1.Panel1.Controls.Add(this.label6);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox8);
            this.splitContainer1.Panel2.Controls.Add(this.Cat);
            this.splitContainer1.Panel2.Controls.Add(this.replace1);
            this.splitContainer1.Panel2.Controls.Add(this.keey);
            this.splitContainer1.Panel2.Controls.Add(this.replace);
            this.splitContainer1.Panel2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.splitContainer1.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel2_Paint);
            this.splitContainer1.Size = new System.Drawing.Size(806, 472);
            this.splitContainer1.SplitterDistance = 372;
            this.splitContainer1.TabIndex = 3;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.richTextBox1);
            this.panel9.Location = new System.Drawing.Point(89, 340);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(182, 62);
            this.panel9.TabIndex = 21;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.Color.Silver;
            this.richTextBox1.Location = new System.Drawing.Point(2, 1);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(174, 59);
            this.richTextBox1.TabIndex = 19;
            this.richTextBox1.Text = "Report";
            this.richTextBox1.Enter += new System.EventHandler(this.richTextBox1_Enter_1);
            this.richTextBox1.Leave += new System.EventHandler(this.richTextBox1_Leave_1);
            // 
            // invaled
            // 
            this.invaled.AutoSize = true;
            this.invaled.ForeColor = System.Drawing.Color.Red;
            this.invaled.Location = new System.Drawing.Point(52, 447);
            this.invaled.Name = "invaled";
            this.invaled.Size = new System.Drawing.Size(0, 13);
            this.invaled.TabIndex = 20;
            // 
            // invalr
            // 
            this.invalr.AutoSize = true;
            this.invalr.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invalr.ForeColor = System.Drawing.Color.Red;
            this.invalr.Location = new System.Drawing.Point(208, 402);
            this.invalr.Name = "invalr";
            this.invalr.Size = new System.Drawing.Size(0, 17);
            this.invalr.TabIndex = 19;
            // 
            // invalf
            // 
            this.invalf.AutoSize = true;
            this.invalf.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invalf.ForeColor = System.Drawing.Color.Red;
            this.invalf.Location = new System.Drawing.Point(208, 288);
            this.invalf.Name = "invalf";
            this.invalf.Size = new System.Drawing.Size(0, 17);
            this.invalf.TabIndex = 18;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(189, 431);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(157, 32);
            this.button11.TabIndex = 17;
            this.button11.Text = "Add To File";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(18, 352);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 21);
            this.label9.TabIndex = 16;
            this.label9.Text = "Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(17, 310);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 28);
            this.label10.TabIndex = 14;
            this.label10.Text = "Report";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(18, 259);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 21);
            this.label8.TabIndex = 12;
            this.label8.Text = "Name";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.Silver;
            this.textBox3.Location = new System.Drawing.Point(91, 257);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(180, 27);
            this.textBox3.TabIndex = 11;
            this.textBox3.Text = "File Name";
            this.textBox3.Enter += new System.EventHandler(this.textBox3_Enter_1);
            this.textBox3.Leave += new System.EventHandler(this.textBox3_Leave_1);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 216);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 28);
            this.label7.TabIndex = 10;
            this.label7.Text = "File Name";
            // 
            // invalkey
            // 
            this.invalkey.AutoSize = true;
            this.invalkey.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invalkey.ForeColor = System.Drawing.Color.Red;
            this.invalkey.Location = new System.Drawing.Point(208, 164);
            this.invalkey.Name = "invalkey";
            this.invalkey.Size = new System.Drawing.Size(0, 17);
            this.invalkey.TabIndex = 9;
            // 
            // invalcat
            // 
            this.invalcat.AutoSize = true;
            this.invalcat.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invalcat.ForeColor = System.Drawing.Color.Red;
            this.invalcat.Location = new System.Drawing.Point(208, 76);
            this.invalcat.Name = "invalcat";
            this.invalcat.Size = new System.Drawing.Size(0, 17);
            this.invalcat.TabIndex = 8;
            // 
            // keyword
            // 
            this.keyword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.keyword.FlatAppearance.BorderSize = 0;
            this.keyword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.keyword.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.keyword.ForeColor = System.Drawing.Color.White;
            this.keyword.Location = new System.Drawing.Point(189, 183);
            this.keyword.Name = "keyword";
            this.keyword.Size = new System.Drawing.Size(157, 32);
            this.keyword.TabIndex = 7;
            this.keyword.Text = "Add Key Word";
            this.keyword.UseVisualStyleBackColor = false;
            this.keyword.Click += new System.EventHandler(this.keyword_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(18, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 21);
            this.label4.TabIndex = 6;
            this.label4.Text = "Name";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.Silver;
            this.textBox2.Location = new System.Drawing.Point(91, 135);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(180, 27);
            this.textBox2.TabIndex = 5;
            this.textBox2.Text = "Key Word";
            this.textBox2.Enter += new System.EventHandler(this.textBox2_Enter);
            this.textBox2.Leave += new System.EventHandler(this.textBox2_Leave_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 28);
            this.label3.TabIndex = 4;
            this.label3.Text = "KeyWord";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 21);
            this.label5.TabIndex = 2;
            this.label5.Text = "Name";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.Silver;
            this.textBox1.Location = new System.Drawing.Point(90, 47);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(181, 27);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "Category";
            this.textBox1.Enter += new System.EventHandler(this.textBox1_Enter);
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(16, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 28);
            this.label6.TabIndex = 0;
            this.label6.Text = "Category";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(344, -8);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(84, 104);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 22;
            this.pictureBox8.TabStop = false;
            // 
            // Cat
            // 
            this.Cat.AutoSize = true;
            this.Cat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Cat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cat.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cat.Location = new System.Drawing.Point(132, 29);
            this.Cat.Name = "Cat";
            this.Cat.Size = new System.Drawing.Size(127, 32);
            this.Cat.TabIndex = 0;
            this.Cat.Text = "                ";
            // 
            // replace1
            // 
            this.replace1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.replace1.Controls.Add(this.panel11);
            this.replace1.Controls.Add(this.panel10);
            this.replace1.Controls.Add(this.button2);
            this.replace1.Controls.Add(this.label14);
            this.replace1.Controls.Add(this.label15);
            this.replace1.Controls.Add(this.label16);
            this.replace1.Location = new System.Drawing.Point(68, 279);
            this.replace1.Name = "replace1";
            this.replace1.Size = new System.Drawing.Size(292, 184);
            this.replace1.TabIndex = 15;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.New);
            this.panel11.Location = new System.Drawing.Point(104, 84);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(172, 43);
            this.panel11.TabIndex = 22;
            // 
            // New
            // 
            this.New.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.New.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.New.ForeColor = System.Drawing.Color.Black;
            this.New.Location = new System.Drawing.Point(3, 6);
            this.New.Name = "New";
            this.New.Size = new System.Drawing.Size(168, 33);
            this.New.TabIndex = 23;
            this.New.Text = "";
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.old);
            this.panel10.Location = new System.Drawing.Point(104, 35);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(172, 43);
            this.panel10.TabIndex = 22;
            // 
            // old
            // 
            this.old.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.old.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.old.ForeColor = System.Drawing.Color.Black;
            this.old.Location = new System.Drawing.Point(-1, -1);
            this.old.Name = "old";
            this.old.Size = new System.Drawing.Size(172, 43);
            this.old.TabIndex = 22;
            this.old.Text = "";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(73, 143);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(142, 32);
            this.button2.TabIndex = 20;
            this.button2.Text = "Replace";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(2, 93);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 21);
            this.label14.TabIndex = 21;
            this.label14.Text = "New Key";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(0, 48);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(69, 21);
            this.label15.TabIndex = 20;
            this.label15.Text = "Old Key";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(78, 5);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(135, 23);
            this.label16.TabIndex = 20;
            this.label16.Text = "Replacement";
            // 
            // keey
            // 
            this.keey.AutoSize = true;
            this.keey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.keey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.keey.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.keey.Location = new System.Drawing.Point(74, 76);
            this.keey.Name = "keey";
            this.keey.Size = new System.Drawing.Size(108, 25);
            this.keey.TabIndex = 14;
            this.keey.Text = "                ";
            // 
            // replace
            // 
            this.replace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.replace.Controls.Add(this.button12);
            this.replace.Controls.Add(this.label13);
            this.replace.Controls.Add(this.label12);
            this.replace.Controls.Add(this.label11);
            this.replace.Controls.Add(this.nw);
            this.replace.Controls.Add(this.od);
            this.replace.Location = new System.Drawing.Point(68, 113);
            this.replace.Name = "replace";
            this.replace.Size = new System.Drawing.Size(292, 145);
            this.replace.TabIndex = 13;
            this.replace.Paint += new System.Windows.Forms.PaintEventHandler(this.replace_Paint);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(72, 105);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(142, 32);
            this.button12.TabIndex = 20;
            this.button12.Text = "Replace";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click_1);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(2, 72);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 21);
            this.label13.TabIndex = 21;
            this.label13.Text = "New Key";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(1, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 21);
            this.label12.TabIndex = 20;
            this.label12.Text = "Old Key";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(73, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(135, 23);
            this.label11.TabIndex = 20;
            this.label11.Text = "Replacement";
            // 
            // nw
            // 
            this.nw.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nw.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nw.Location = new System.Drawing.Point(132, 69);
            this.nw.Name = "nw";
            this.nw.Size = new System.Drawing.Size(144, 27);
            this.nw.TabIndex = 1;
            // 
            // od
            // 
            this.od.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.od.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.od.Location = new System.Drawing.Point(132, 35);
            this.od.Name = "od";
            this.od.Size = new System.Drawing.Size(144, 27);
            this.od.TabIndex = 0;
            // 
            // searchkeyword
            // 
            this.searchkeyword.Controls.Add(this.searchfile);
            this.searchkeyword.Controls.Add(this.panel13);
            this.searchkeyword.Controls.Add(this.textBox8);
            this.searchkeyword.Controls.Add(this.label25);
            this.searchkeyword.Controls.Add(this.searchK);
            this.searchkeyword.Controls.Add(this.textBox4);
            this.searchkeyword.Controls.Add(this.label17);
            this.searchkeyword.Controls.Add(this.label26);
            this.searchkeyword.Controls.Add(this.label24);
            this.searchkeyword.Controls.Add(this.label23);
            this.searchkeyword.Controls.Add(this.panel15);
            this.searchkeyword.Controls.Add(this.panel18);
            this.searchkeyword.Location = new System.Drawing.Point(58, 3);
            this.searchkeyword.Name = "searchkeyword";
            this.searchkeyword.Size = new System.Drawing.Size(666, 478);
            this.searchkeyword.TabIndex = 25;
            this.searchkeyword.Paint += new System.Windows.Forms.PaintEventHandler(this.searchkeyword_Paint);
            // 
            // searchfile
            // 
            this.searchfile.Controls.Add(this.searchCat);
            this.searchfile.Controls.Add(this.label27);
            this.searchfile.Controls.Add(this.panel12);
            this.searchfile.Controls.Add(this.textBox9);
            this.searchfile.Controls.Add(this.label);
            this.searchfile.Controls.Add(this.searchF);
            this.searchfile.Location = new System.Drawing.Point(0, 0);
            this.searchfile.Name = "searchfile";
            this.searchfile.Size = new System.Drawing.Size(666, 448);
            this.searchfile.TabIndex = 37;
            // 
            // searchCat
            // 
            this.searchCat.Controls.Add(this.searchfcat);
            this.searchCat.Controls.Add(this.label29);
            this.searchCat.Controls.Add(this.panel14);
            this.searchCat.Controls.Add(this.textBox10);
            this.searchCat.Controls.Add(this.label28);
            this.searchCat.Controls.Add(this.searchC);
            this.searchCat.Location = new System.Drawing.Point(0, 0);
            this.searchCat.Name = "searchCat";
            this.searchCat.Size = new System.Drawing.Size(666, 448);
            this.searchCat.TabIndex = 40;
            // 
            // searchfcat
            // 
            this.searchfcat.Controls.Add(this.label31);
            this.searchfcat.Controls.Add(this.panel16);
            this.searchfcat.Controls.Add(this.textBox11);
            this.searchfcat.Controls.Add(this.label30);
            this.searchfcat.Controls.Add(this.button15);
            this.searchfcat.Location = new System.Drawing.Point(0, 0);
            this.searchfcat.Name = "searchfcat";
            this.searchfcat.Size = new System.Drawing.Size(666, 448);
            this.searchfcat.TabIndex = 43;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(305, 115);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(44, 22);
            this.label31.TabIndex = 45;
            this.label31.Text = "Files";
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.richTextBox7);
            this.panel16.Location = new System.Drawing.Point(16, 158);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(635, 287);
            this.panel16.TabIndex = 44;
            // 
            // richTextBox7
            // 
            this.richTextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox7.Location = new System.Drawing.Point(3, 3);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.Size = new System.Drawing.Size(629, 279);
            this.richTextBox7.TabIndex = 29;
            this.richTextBox7.Text = "";
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.White;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.ForeColor = System.Drawing.Color.Silver;
            this.textBox11.Location = new System.Drawing.Point(240, 13);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(185, 27);
            this.textBox11.TabIndex = 43;
            this.textBox11.Text = "Category";
            this.textBox11.Enter += new System.EventHandler(this.textBox11_Enter);
            this.textBox11.Leave += new System.EventHandler(this.textBox11_Leave);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(113, 15);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(107, 25);
            this.label30.TabIndex = 42;
            this.label30.Text = "Category";
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(403, 47);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(145, 33);
            this.button15.TabIndex = 41;
            this.button15.Text = "Search";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(239, 124);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(193, 22);
            this.label29.TabIndex = 42;
            this.label29.Text = "Category KeyWords";
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.richTextBox6);
            this.panel14.Location = new System.Drawing.Point(20, 159);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(635, 287);
            this.panel14.TabIndex = 41;
            // 
            // richTextBox6
            // 
            this.richTextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox6.Location = new System.Drawing.Point(3, 3);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.Size = new System.Drawing.Size(629, 279);
            this.richTextBox6.TabIndex = 29;
            this.richTextBox6.Text = "";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.White;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.ForeColor = System.Drawing.Color.Silver;
            this.textBox10.Location = new System.Drawing.Point(241, 12);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(185, 27);
            this.textBox10.TabIndex = 40;
            this.textBox10.Text = "Category";
            this.textBox10.Enter += new System.EventHandler(this.textBox10_Enter);
            this.textBox10.Leave += new System.EventHandler(this.textBox10_Leave);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(113, 13);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(107, 25);
            this.label28.TabIndex = 39;
            this.label28.Text = "Category";
            // 
            // searchC
            // 
            this.searchC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.searchC.FlatAppearance.BorderSize = 0;
            this.searchC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchC.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchC.ForeColor = System.Drawing.Color.White;
            this.searchC.Location = new System.Drawing.Point(403, 50);
            this.searchC.Name = "searchC";
            this.searchC.Size = new System.Drawing.Size(145, 33);
            this.searchC.TabIndex = 38;
            this.searchC.Text = "Search";
            this.searchC.UseVisualStyleBackColor = false;
            this.searchC.Click += new System.EventHandler(this.searchC_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(249, 116);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(161, 22);
            this.label27.TabIndex = 39;
            this.label27.Text = "File Components";
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.richTextBox5);
            this.panel12.Location = new System.Drawing.Point(18, 159);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(635, 287);
            this.panel12.TabIndex = 38;
            // 
            // richTextBox5
            // 
            this.richTextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox5.Location = new System.Drawing.Point(3, 3);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(629, 280);
            this.richTextBox5.TabIndex = 29;
            this.richTextBox5.Text = "";
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.White;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.ForeColor = System.Drawing.Color.Silver;
            this.textBox9.Location = new System.Drawing.Point(241, 13);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(185, 27);
            this.textBox9.TabIndex = 37;
            this.textBox9.Text = "File Name";
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            this.textBox9.Enter += new System.EventHandler(this.textBox9_Enter);
            this.textBox9.Leave += new System.EventHandler(this.textBox9_Leave);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(113, 12);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(114, 25);
            this.label.TabIndex = 36;
            this.label.Text = "File Name";
            // 
            // searchF
            // 
            this.searchF.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.searchF.FlatAppearance.BorderSize = 0;
            this.searchF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchF.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchF.ForeColor = System.Drawing.Color.White;
            this.searchF.Location = new System.Drawing.Point(403, 49);
            this.searchF.Name = "searchF";
            this.searchF.Size = new System.Drawing.Size(145, 33);
            this.searchF.TabIndex = 35;
            this.searchF.Text = "Search";
            this.searchF.UseVisualStyleBackColor = false;
            this.searchF.Click += new System.EventHandler(this.searchF_Click);
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.richTextBox4);
            this.panel13.Location = new System.Drawing.Point(19, 185);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(192, 261);
            this.panel13.TabIndex = 36;
            // 
            // richTextBox4
            // 
            this.richTextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox4.Location = new System.Drawing.Point(3, 3);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(184, 255);
            this.richTextBox4.TabIndex = 29;
            this.richTextBox4.Text = "";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.White;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.ForeColor = System.Drawing.Color.Silver;
            this.textBox8.Location = new System.Drawing.Point(229, 15);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(185, 27);
            this.textBox8.TabIndex = 34;
            this.textBox8.Text = "KeyWord";
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            this.textBox8.Enter += new System.EventHandler(this.textBox8_Enter);
            this.textBox8.Leave += new System.EventHandler(this.textBox8_Leave);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(104, 14);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(103, 25);
            this.label25.TabIndex = 33;
            this.label25.Text = "KeyWord";
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // searchK
            // 
            this.searchK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.searchK.FlatAppearance.BorderSize = 0;
            this.searchK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchK.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchK.ForeColor = System.Drawing.Color.White;
            this.searchK.Location = new System.Drawing.Point(429, 52);
            this.searchK.Name = "searchK";
            this.searchK.Size = new System.Drawing.Size(199, 33);
            this.searchK.TabIndex = 32;
            this.searchK.Text = "Search";
            this.searchK.UseVisualStyleBackColor = false;
            this.searchK.Click += new System.EventHandler(this.searchK_Click);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.Color.Silver;
            this.textBox4.Location = new System.Drawing.Point(237, 122);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(185, 27);
            this.textBox4.TabIndex = 31;
            this.textBox4.Text = "Number";
            this.textBox4.Enter += new System.EventHandler(this.textBox4_Enter_1);
            this.textBox4.Leave += new System.EventHandler(this.textBox4_Leave_1);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(225, 91);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(213, 24);
            this.label17.TabIndex = 30;
            this.label17.Text = "Repetation Number";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(522, 150);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(49, 21);
            this.label26.TabIndex = 28;
            this.label26.Text = "Lines";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(275, 150);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(102, 21);
            this.label24.TabIndex = 27;
            this.label24.Text = "Categories";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(71, 150);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(91, 21);
            this.label23.TabIndex = 26;
            this.label23.Text = "File Name";
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.richTextBox9);
            this.panel15.Location = new System.Drawing.Point(238, 185);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(192, 261);
            this.panel15.TabIndex = 38;
            // 
            // richTextBox9
            // 
            this.richTextBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox9.Location = new System.Drawing.Point(3, 3);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.Size = new System.Drawing.Size(184, 255);
            this.richTextBox9.TabIndex = 29;
            this.richTextBox9.Text = "";
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.richTextBox10);
            this.panel18.Location = new System.Drawing.Point(453, 185);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(192, 261);
            this.panel18.TabIndex = 39;
            // 
            // richTextBox10
            // 
            this.richTextBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox10.Location = new System.Drawing.Point(3, 3);
            this.richTextBox10.Name = "richTextBox10";
            this.richTextBox10.Size = new System.Drawing.Size(184, 255);
            this.richTextBox10.TabIndex = 29;
            this.richTextBox10.Text = "";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(723, -1);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(84, 104);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 24;
            this.pictureBox10.TabStop = false;
            // 
            // textBox13
            // 
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox13.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.ForeColor = System.Drawing.Color.Silver;
            this.textBox13.Location = new System.Drawing.Point(298, 15);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(185, 27);
            this.textBox13.TabIndex = 29;
            this.textBox13.Text = "File Name";
            this.textBox13.Enter += new System.EventHandler(this.textBox13_Enter);
            this.textBox13.Leave += new System.EventHandler(this.textBox13_Leave_1);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(170, 17);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(114, 25);
            this.label33.TabIndex = 28;
            this.label33.Text = "File Name";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(436, 90);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(145, 33);
            this.button9.TabIndex = 27;
            this.button9.Text = "Search";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox12
            // 
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.ForeColor = System.Drawing.Color.Silver;
            this.textBox12.Location = new System.Drawing.Point(297, 55);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(185, 27);
            this.textBox12.TabIndex = 26;
            this.textBox12.Text = "Category";
            this.textBox12.Enter += new System.EventHandler(this.textBox12_Enter);
            this.textBox12.Leave += new System.EventHandler(this.textBox12_Leave);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(169, 57);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(107, 25);
            this.label32.TabIndex = 25;
            this.label32.Text = "Category";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(723, -1);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(84, 104);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 24;
            this.pictureBox11.TabStop = false;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(243, 146);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(317, 22);
            this.label34.TabIndex = 46;
            this.label34.Text = "Category KeyWords is Highlighted";
            // 
            // panel17
            // 
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.richTextBox8);
            this.panel17.Location = new System.Drawing.Point(19, 181);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(761, 303);
            this.panel17.TabIndex = 45;
            // 
            // richTextBox8
            // 
            this.richTextBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox8.Location = new System.Drawing.Point(3, 3);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.Size = new System.Drawing.Size(753, 295);
            this.richTextBox8.TabIndex = 29;
            this.richTextBox8.Text = "";
            // 
            // textBox14
            // 
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox14.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.ForeColor = System.Drawing.Color.Silver;
            this.textBox14.Location = new System.Drawing.Point(295, 5);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(185, 27);
            this.textBox14.TabIndex = 26;
            this.textBox14.Text = "File Name";
            this.textBox14.Enter += new System.EventHandler(this.textBox14_Enter);
            this.textBox14.Leave += new System.EventHandler(this.textBox14_Leave);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(167, 7);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(114, 25);
            this.label35.TabIndex = 25;
            this.label35.Text = "File Name";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.richTextBox2);
            this.panel7.Location = new System.Drawing.Point(24, 180);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(233, 280);
            this.panel7.TabIndex = 10;
            // 
            // richTextBox2
            // 
            this.richTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox2.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.ForeColor = System.Drawing.Color.Silver;
            this.richTextBox2.Location = new System.Drawing.Point(1, 5);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(231, 270);
            this.richTextBox2.TabIndex = 3;
            this.richTextBox2.Text = "KeyWord";
            this.richTextBox2.Enter += new System.EventHandler(this.richTextBox2_Enter);
            this.richTextBox2.Leave += new System.EventHandler(this.richTextBox2_Leave);
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.richTextBox3);
            this.panel6.Location = new System.Drawing.Point(294, 180);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(233, 280);
            this.panel6.TabIndex = 9;
            // 
            // richTextBox3
            // 
            this.richTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox3.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox3.ForeColor = System.Drawing.Color.Silver;
            this.richTextBox3.Location = new System.Drawing.Point(1, 5);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(231, 270);
            this.richTextBox3.TabIndex = 3;
            this.richTextBox3.Text = "Report";
            this.richTextBox3.Enter += new System.EventHandler(this.richTextBox3_Enter);
            this.richTextBox3.Leave += new System.EventHandler(this.richTextBox3_Leave);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(303, 469);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(205, 33);
            this.button13.TabIndex = 8;
            this.button13.Text = "Edit";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click_1);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(460, 87);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(145, 33);
            this.button10.TabIndex = 7;
            this.button10.Text = "Search";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.pictureBox7);
            this.panel8.Controls.Add(this.textBox7);
            this.panel8.Controls.Add(this.label22);
            this.panel8.Controls.Add(this.textBox6);
            this.panel8.Controls.Add(this.label21);
            this.panel8.Location = new System.Drawing.Point(569, 178);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(233, 280);
            this.panel8.TabIndex = 6;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(68, 167);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(101, 106);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 10;
            this.pictureBox7.TabStop = false;
            // 
            // textBox7
            // 
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox7.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.ForeColor = System.Drawing.Color.Silver;
            this.textBox7.Location = new System.Drawing.Point(5, 132);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(221, 31);
            this.textBox7.TabIndex = 9;
            this.textBox7.Text = "File Name";
            this.textBox7.Enter += new System.EventHandler(this.textBox7_Enter);
            this.textBox7.Leave += new System.EventHandler(this.textBox7_Leave);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(3, 93);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(98, 22);
            this.label22.TabIndex = 8;
            this.label22.Text = "File Name";
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.ForeColor = System.Drawing.Color.Silver;
            this.textBox6.Location = new System.Drawing.Point(5, 46);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(221, 31);
            this.textBox6.TabIndex = 7;
            this.textBox6.Text = "Category";
            this.textBox6.Enter += new System.EventHandler(this.textBox6_Enter);
            this.textBox6.Leave += new System.EventHandler(this.textBox6_Leave);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(3, 7);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(99, 22);
            this.label21.TabIndex = 6;
            this.label21.Text = "Category";
            // 
            // textBox5
            // 
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.ForeColor = System.Drawing.Color.Silver;
            this.textBox5.Location = new System.Drawing.Point(296, 50);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(185, 27);
            this.textBox5.TabIndex = 5;
            this.textBox5.Text = "Category";
            this.textBox5.Enter += new System.EventHandler(this.textBox5_Enter);
            this.textBox5.Leave += new System.EventHandler(this.textBox5_Leave);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(168, 52);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(107, 25);
            this.label20.TabIndex = 4;
            this.label20.Text = "Category";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(373, 138);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 22);
            this.label19.TabIndex = 2;
            this.label19.Text = "Report";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(88, 138);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(92, 22);
            this.label18.TabIndex = 0;
            this.label18.Text = "KeyWord";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(723, -1);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(84, 104);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 23;
            this.pictureBox9.TabStop = false;
            // 
            // arrow4
            // 
            this.arrow4.BackColor = System.Drawing.Color.Transparent;
            this.arrow4.Image = ((System.Drawing.Image)(resources.GetObject("arrow4.Image")));
            this.arrow4.Location = new System.Drawing.Point(725, 648);
            this.arrow4.Name = "arrow4";
            this.arrow4.Size = new System.Drawing.Size(47, 36);
            this.arrow4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow4.TabIndex = 28;
            this.arrow4.TabStop = false;
            // 
            // arrow3
            // 
            this.arrow3.BackColor = System.Drawing.Color.Transparent;
            this.arrow3.Image = ((System.Drawing.Image)(resources.GetObject("arrow3.Image")));
            this.arrow3.Location = new System.Drawing.Point(777, 648);
            this.arrow3.Name = "arrow3";
            this.arrow3.Size = new System.Drawing.Size(47, 36);
            this.arrow3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow3.TabIndex = 27;
            this.arrow3.TabStop = false;
            // 
            // filname
            // 
            this.filname.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.filname.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.filname.ForeColor = System.Drawing.Color.Black;
            this.filname.Location = new System.Drawing.Point(686, 622);
            this.filname.Name = "filname";
            this.filname.Size = new System.Drawing.Size(80, 26);
            this.filname.TabIndex = 30;
            this.filname.Text = "File";
            this.filname.UseVisualStyleBackColor = true;
            this.filname.Click += new System.EventHandler(this.filname_Click);
            // 
            // categ
            // 
            this.categ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.categ.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categ.ForeColor = System.Drawing.Color.Black;
            this.categ.Location = new System.Drawing.Point(784, 622);
            this.categ.Name = "categ";
            this.categ.Size = new System.Drawing.Size(80, 26);
            this.categ.TabIndex = 29;
            this.categ.Text = "Category";
            this.categ.UseVisualStyleBackColor = true;
            this.categ.Click += new System.EventHandler(this.categ_Click);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1091, 717);
            this.Controls.Add(this.fn);
            this.Controls.Add(this.filname);
            this.Controls.Add(this.categ);
            this.Controls.Add(this.arrow4);
            this.Controls.Add(this.arrow3);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.notifications);
            this.Controls.Add(this.arrow1);
            this.Controls.Add(this.arrow2);
            this.Controls.Add(this.rep);
            this.Controls.Add(this.kw);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.ca);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.side.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.editt.ResumeLayout(false);
            this.editt.PerformLayout();
            this.highlight.ResumeLayout(false);
            this.highlight.PerformLayout();
            this.search1.ResumeLayout(false);
            this.Cate.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.replace1.ResumeLayout(false);
            this.replace1.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.replace.ResumeLayout(false);
            this.replace.PerformLayout();
            this.searchkeyword.ResumeLayout(false);
            this.searchkeyword.PerformLayout();
            this.searchfile.ResumeLayout(false);
            this.searchfile.PerformLayout();
            this.searchCat.ResumeLayout(false);
            this.searchCat.PerformLayout();
            this.searchfcat.ResumeLayout(false);
            this.searchfcat.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.panel17.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ca;
        private System.Windows.Forms.Panel side;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button kw;
        private System.Windows.Forms.Button rep;
        private System.Windows.Forms.Button fn;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox arrow2;
        private System.Windows.Forms.PictureBox arrow1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label notifications;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button EditCat;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel search1;
        private System.Windows.Forms.Panel editt;
        private System.Windows.Forms.Panel Cate;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label invaled;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label invalr;
        private System.Windows.Forms.Label invalf;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label invalkey;
        private System.Windows.Forms.Label invalcat;
        private System.Windows.Forms.Button keyword;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Cat;
        private System.Windows.Forms.Panel replace1;
        private System.Windows.Forms.RichTextBox New;
        private System.Windows.Forms.RichTextBox old;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label keey;
        private System.Windows.Forms.Panel replace;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox nw;
        private System.Windows.Forms.TextBox od;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel searchkeyword;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button searchK;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel searchfile;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Button searchF;
        private System.Windows.Forms.Panel searchCat;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button searchC;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.PictureBox arrow4;
        private System.Windows.Forms.PictureBox arrow3;
        private System.Windows.Forms.Button filname;
        private System.Windows.Forms.Button categ;
        private System.Windows.Forms.Panel searchfcat;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Panel highlight;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.RichTextBox richTextBox10;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label35;
    }
}

